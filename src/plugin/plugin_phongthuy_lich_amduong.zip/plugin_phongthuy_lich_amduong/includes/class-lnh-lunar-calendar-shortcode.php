<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class LNH_Lunar_Calendar_Shortcode {
    
    public function __construct() {
        add_shortcode( 'lnh_lunar_calendar', [ $this, 'render_shortcode' ] );
    }

    public function render_shortcode( $atts ) {
        wp_enqueue_style('lnhlc-styles');
        wp_enqueue_script('lnhlc-script');

        $options = get_option( LNHLC_OPTIONS_NAME );
        $default_theme = !empty($options['default_theme']) ? $options['default_theme'] : 'light';

        $current_month = (int) wp_date('n');
        $current_year = (int) wp_date('Y');

        // Check for navigation parameters with nonce verification
        if ( isset( $_GET['lnhlc_nonce'] ) && wp_verify_nonce( sanitize_key( $_GET['lnhlc_nonce'] ), 'lnhlc_calendar_nav' ) ) {
            if ( isset( $_GET['lnhlc_month'] ) ) {
                $month_input = intval( $_GET['lnhlc_month'] );
                // Validate month (1-12)
                if ( $month_input >= 1 && $month_input <= 12 ) {
                    $current_month = $month_input;
                }
            }
            if ( isset( $_GET['lnhlc_year'] ) ) {
                $year_input = intval( $_GET['lnhlc_year'] );
                // Validate year (1940-2099)
                if ( $year_input >= 1940 && $year_input <= 2099 ) {
                    $current_year = $year_input;
                }
            }
        }

        $atts = shortcode_atts(
            [
                'layout' => 'widget',
                'theme'  => $default_theme,
                'month'  => $current_month,
                'year'   => $current_year,
            ],
            $atts,
            'lnh_lunar_calendar'
        );

        $layout = sanitize_key( $atts['layout'] );
        
        // **FIX**: Don't cache 'full' layout to avoid nonce expiration issues with navigation
        // Nonce expires after 12-24 hours but cached HTML can be served longer, breaking navigation buttons
        $should_cache = ($layout !== 'full');
        
        $output = false; // Default to regenerate
        
        if ($should_cache) {
            $cache_key_extra = ($layout === 'full') ? $atts['year'] . '_' . $atts['month'] : wp_date('Ymd');
            $options_hash = md5( serialize( get_option( LNHLC_OPTIONS_NAME ) ) );
            $transient_key = 'lnhlc_cache_v' . LNHLC_VERSION . '_' . $options_hash . '_' . md5( serialize( $atts ) . $cache_key_extra );
            $output = get_transient( $transient_key );
        }

        if ( false === $output ) {
            ob_start();
            
            $lunar_data = [];
            if ($layout === 'full') {
                $month_data = $this->get_full_month_data($atts['month'], $atts['year']);
                if (empty($month_data)) {
                    echo '<!-- LNH Lunar Calendar: Error generating full month data. -->';
                } else {
                    $lunar_data['month_data'] = $month_data;
                    $lunar_data['current_month'] = $atts['month'];
                    $lunar_data['current_year'] = $atts['year'];
                    
                    // **FIX**: Display appropriate day in header
                    $today_ts = time();
                    $today_day = (int)wp_date('j', $today_ts);
                    $today_month = (int)wp_date('n', $today_ts);
                    $today_year = (int)wp_date('Y', $today_ts);
                    
                    // If we're viewing current month AND current year, show today's data
                    if ((int)$atts['month'] === $today_month && (int)$atts['year'] === $today_year) {
                        $header_day_data = lnhlc_get_lunar_date_data($today_ts);
                    } else {
                        // Otherwise show the 1st day of the month being viewed
                        $first_day_ts = mktime(0, 0, 0, (int)$atts['month'], 1, (int)$atts['year']);
                        $header_day_data = lnhlc_get_lunar_date_data($first_day_ts);
                    }
                    
                    $lunar_data['today_data'] = $header_day_data;
                }
            } else {
                $lunar_data = lnhlc_get_lunar_date_data();
            }

            $theme = sanitize_key( $atts['theme'] );
            echo '<div class="lnhlc-container theme-' . esc_attr($theme) . ' layout-' . esc_attr($layout) . '">';
            $template_path = LNHLC_PLUGIN_DIR . "templates/layout-{$layout}.php";
            if ( file_exists( $template_path ) && !empty($lunar_data) ) {
                include $template_path;
            } else {
                $lunar_data = lnhlc_get_lunar_date_data();
                include LNHLC_PLUGIN_DIR . 'templates/layout-widget.php';
            }
            echo '</div>';
            $output = ob_get_clean();
            
            // Only cache non-full layouts
            if ($should_cache) {
                set_transient( $transient_key, $output, 3 * HOUR_IN_SECONDS );
            }
        }
        return $output;
    }

    private function get_full_month_data($month, $year) {
        $calendar_data = [];
        $first_day_timestamp = mktime(0, 0, 0, $month, 1, $year);
        $first_day_of_week = (int)wp_date('N', $first_day_timestamp);
        $start_timestamp = $first_day_timestamp - (($first_day_of_week - 1) * 86400);
        $number_of_cells = 42;

        for ($i = 0; $i < $number_of_cells; $i++) {
            $current_timestamp = $start_timestamp + ($i * 86400);
            $day_data = lnhlc_get_lunar_date_data($current_timestamp);
            if ($day_data) {
                $day_data['is_current_month'] = ((int)wp_date('n', $current_timestamp) == $month);
                $calendar_data[] = $day_data;
            }
        }
        return $calendar_data;
    }
}
