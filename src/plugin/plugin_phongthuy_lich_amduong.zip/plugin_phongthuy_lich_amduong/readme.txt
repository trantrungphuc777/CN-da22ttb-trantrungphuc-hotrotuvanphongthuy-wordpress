=== LNH Lunar Calendar ===
Tags: lunar calendar, vietnamese calendar, shortcode, dark mode, âm lịch, lịch vạn niên
Requires at least: 5.0
Tested up to: 6.8
Stable tag: 2.8.5
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Requires PHP: 7.0

Display an accurate Vietnamese Lunar-Solar Calendar via shortcode. Supports multiple layouts, dark mode, interactions, and dynamic Zodiac Hours.

== Description ==

LNH Lunar Calendar is a simple yet powerful plugin that allows you to easily insert a detailed Lunar-Solar calendar block anywhere on your WordPress site using a shortcode. The plugin is designed with a modern, responsive interface and provides accurate information about the lunar date, Can Chi (Stem-Branch), and dynamic Zodiac Hours calculated for each specific day.

This is an essential tool for websites targeting a Vietnamese audience, helping to enrich content and provide a culturally relevant experience.

Key Features:

Flexible Shortcode: Use [lnh_lunar_calendar] to display the calendar with various options.

Multiple Layouts & Themes:

widget: A compact block, perfect for sidebars or footers.

full: Displays a full monthly calendar with an integrated details header.

inline: Shows date information in a single, clean line.

theme="dark": A beautiful dark mode is available for all layouts.

Smart Interaction: Users can click any day in the full calendar to see its detailed information (including Zodiac Hours) updated instantly in the header.

Dynamic Zodiac Hours: The Zodiac Hours (Giờ Hoàng Đạo) are accurately calculated for each day based on its Earthly Branch (Địa Chi).

Easy Customization: Allows users to translate basic text strings (like "Day", "Month", "Year"...) directly from the settings page.

Accurate & High-Performance: Uses a verified astronomical algorithm for date conversion and the smart Transients API for caching to ensure the fastest page load times.

Responsive Design: Displays beautifully on all devices, from desktops to mobile phones, including abbreviated weekday names on smaller screens.

== Installation ==

Upload the lnh-lunar-calendar folder to the /wp-content/plugins/ directory.

Activate the plugin through the 'Plugins' menu in WordPress.

Go to Settings > LNH Lunar Calendar to customize default settings and translations.

Use the shortcode [lnh_lunar_calendar] in your posts, pages, or widgets.

== Frequently Asked Questions ==

= How do I use the shortcode? =

You can insert the shortcode into any WordPress text editor. Here are some examples:

Basic Widget: [lnh_lunar_calendar]

Full Month Calendar: [lnh_lunar_calendar layout="full"]

Using the Dark Theme: [lnh_lunar_calendar layout="full" theme="dark"]

= How does the interactive feature work? =

The layout="full" shortcode automatically includes a detailed header. When you click on any day in the calendar grid, this header will update to show the detailed information for the selected day. If you also place a [lunar_calendar] widget on the same page, it will be updated as well.

= Can I translate words like "Day", "Month", "Monday", etc.? =

Yes. Go to Settings > LNH Lunar Calendar > Translate. Here you can enter custom translations for the text strings displayed on the front end.

== Screenshots ==

The full monthly calendar (layout="full") with its integrated details header.

The full calendar in the new dark mode (theme="dark").

The interactive feature in action: a user clicks on a day, and the header updates with the correct details.

The plugin's settings page with the "General" and "Translate" tabs.

== Changelog ==

= 2.8.5 =

Feature: Added a beautiful dark mode (theme="dark") for the full calendar layout.

= 2.8.3 =

Fix: Resolved a critical bug where calendar navigation (next/prev month) would fail if the mbstring PHP extension was not enabled on the server.

= 2.8.2 =

Tweak: Weekday headers in the full calendar now automatically switch to single-letter abbreviations on mobile devices for a cleaner look.

= 2.8.1 =

Tweak: Added a current-day class to the present day in the full calendar for easier styling.

= 2.8.0 =

Major Feature: Implemented dynamic Zodiac Hours. The auspicious hours are now accurately calculated for each day based on its specific Earthly Branch (Chi).

= 2.7.0 =

Feature: Integrated a widget-like details header directly into the layout="full" view for a more comprehensive experience.

= 2.6.1 =

Fix: Resolved a JavaScript Invalid URL error by rewriting the navigation logic to be more robust.

= 2.5.1 =

Fix: Corrected a bug where the month's Can Chi (Stem-Branch) was missing on the initial load and showed "undefined" on click.

= 2.5.0 =

Fix: Updated plugin to comply with WordPress.org guidelines, including author information, English readme, and proper code prefixing.

= 1.0.0 =

Initial release.

== Upgrade Notice ==

= 2.8.5 =
This version adds a new dark theme and several stability fixes. Updating is recommended for all users.