<?php
/**
 * Template for the inline layout.
 * Variables available: $lunar_data, $atts
 */
if ( ! defined( 'ABSPATH' ) ) exit;
?>
<span class="lnhlc-inline">
    <?php echo esc_html($lunar_data['weekday']); ?>, 
    <?php printf('%s/%s/%s', esc_html($lunar_data['solar_day']), esc_html($lunar_data['solar_month']), esc_html($lunar_data['solar_year'])); ?>
    (<?php printf(
        '%s %s/%s %s', 
        esc_html(lnhlc_t('lunar_date')), 
        esc_html($lunar_data['lunar_day']), 
        esc_html($lunar_data['lunar_month']),
        esc_html($lunar_data['can_chi_year'])
    ); ?>)
</span>
