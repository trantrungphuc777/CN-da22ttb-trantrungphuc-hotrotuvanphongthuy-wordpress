<?php 
if (!defined('ABSPATH')) exit;

// check key pro
add_action('wp_ajax_swpt_check_license', function(){
    check_ajax_referer('swpt_check_license_nonce');
    if (!current_user_can('manage_options')) wp_send_json_error('no-permission');

    $key = isset($_POST['key']) ? sanitize_text_field($_POST['key']) : '';
    if (!$key) wp_send_json_error('empty-key');

    // swpt_validate_key đến từ includes/license-validate.php
    $ok = function_exists('swpt_validate_key') ? swpt_validate_key($key, home_url()) : false;
    $ok ? wp_send_json_success() : wp_send_json_error();
});


/* Đăng ký ajax */
add_action('wp_ajax_sw_calculate_age','swpt_handle_ajax');
add_action('wp_ajax_nopriv_sw_calculate_age','swpt_handle_ajax');

function swpt_handle_ajax() {
	check_ajax_referer('swpt_nonce','_ajax_nonce');
	
	$year = isset($_POST['birth_year']) ? intval($_POST['birth_year']) : 0;
	
	$res = swpt_calc_can_chi_menh($year); // trả về ['can'=>..., 'chi'=>..., 'can_chi'=>..., 'menh'=>...]
    if (!is_array($res) || empty($res['can_chi'])) {
        wp_send_json_error('Không tính được Can Chi');
    }

    $can     = $res['can'];
    $chi     = $res['chi'];
    $can_chi = $res['can_chi'];
    $menh    = $res['menh'];
	
	$palettes = swpt_palettes();
	$mau_menh = $palettes[$menh];
	
	// màu bản mệnh
	$mau_bm = $mau_menh["tuong_hop"]['mauhop'];
	$maubm_css = $mau_menh["tuong_hop"]['maucss'];
	$html_maubm = '<div class="color-box">';
		
	foreach ($maubm_css as $hex_maubm ) {
		$html_maubm .= "<div class='color-item' style='background-color: $hex_maubm;'></div>";
	}
		
	$html_maubm .= '</div>';
	
	// màu sinh vượng
	$mau_sv = $mau_menh["tuong_sinh"]['sinh_vuong'];
	$mausv_css = $mau_menh["tuong_sinh"]['maucss'];
	$html_mausv = '<div class="color-box">';
		
	foreach ($mausv_css as $hex_mausv ) {
		$html_mausv .= "<div class='color-item' style='background-color: $hex_mausv;'></div>";
	}
		
	$html_mausv .= '</div>';
	
	// Màu khắc chế
	$mau_kc = $mau_menh["khac_che"]['khac'];
	$maukc_css = $mau_menh["khac_che"]['maucss'];
	$html_maukc = '<div class="color-box">';
		
	foreach ($maukc_css as $hex_maukc ) {
		$html_maukc .= "<div class='color-item' style='background-color: $hex_maukc;'></div>";
	}
		
	$html_maukc .= '</div>';
	
	 // 👉 Lấy option từ admin
    $opts = get_option('swpt_options', []);
    $default_result_text = !empty($opts['default_result_text'])
        ? wpautop($opts['default_result_text'])
        : '';
	$product = !empty($opts['product_text']) ? esc_html($opts['product_text']) : 'sản phẩm';
	// output result 
	
	$output = '<h2> Thông tin gia chủ '.$can_chi . ' '.$year. '</h2>';
	$output .= '<table class="table_info_menh"><tbody>';
	$output .= '<tr><td>Năm sinh dương lịch:</td><td>'.$year.'</td></tr>';
	$output .= '<tr><td>Tuổi gia chủ:</td><td>'.$can.' '.$chi.'</td></tr>';
	$output .= '<tr><td>Mệnh trong ngũ hành:</td><td>Mệnh '.$menh.'</td></tr>';
    $output .= '</tbody></table>';
	$output .= '<h2>Màu nội thất hợp với tuổi ' . $can_chi.' ' . $year . '</h2>';
	$output .= '<table class="color-info-table"><tbody>';
	$output .= '<tr><td><strong>Màu bản mệnh gia chủ:</strong></td><td><strong>'.$menh.'</strong></td>';
	$output .= '<td>'.$html_maubm. '</td> </tr>';
	$output .= '<tr><td><strong>Màu tương sinh:</strong></td><td><strong>'.$mau_sv.'</strong></td>';
	$output .= '<td>'.$html_mausv. '</td> </tr>';
	$output .= '<tr><td><strong>Màu tương khắc:</strong></td><td><strong>'.$mau_kc.'</strong></td>';
	$output .= '<td>'.$html_maukc. '</td> </tr>';
	$output .= '</tbody></table>';
	
	// Ghép thêm text mặc định sau khi submit (nếu có)
    if ($default_result_text) {
        $output .= '<div class="after-result-text">'.$default_result_text.'</div>';
    }
	
	// text sau khi xử lý mệnh hợp màu 
	$output .= '<p><strong>Bạn thuộc mệnh ' . $menh. '. Màu hợp với tuổi:</strong></p>';
	$output .= $html_maubm;
	$output .= '<p>Đây là các màu chủ đạo của bạn, bạn có thể trải nghiệm thử nội thất theo màu này.</p>';
	
	// màu sinh vượng meta
	$output .= '<p><strong>'. $mau_sv . ' sinh ' .$menh. '. Màu tương sinh với tuổi:</strong></p>';
	$output .= $html_mausv;
	$output .= '<p>Đây là các màu sinh vượng của bạn, nên phối hợp nội thất màu này cùng màu chủ đạo để gia tăng may mắn và cân bằng phong thuỷ gia đạo.</p>';
	
	// màu khắc chế meta
	$output .= '<p><strong>' .$mau_kc .' khắc ' . $menh .'. Màu tương khắc với tuổi:</strong></p>';
	$output .= $html_maukc;
	$output .= '<p>Đây là các màu khắc chế với màu sắc chủ đạo của bạn. Nên hạn chế dùng.</p>';
	
	wp_send_json_success(['message' => $output ]);
}

?>