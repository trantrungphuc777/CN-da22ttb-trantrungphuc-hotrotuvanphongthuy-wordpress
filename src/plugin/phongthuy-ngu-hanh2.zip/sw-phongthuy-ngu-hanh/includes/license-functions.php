<?php
if (!defined('SWPT_SECRET')) {
    define('SWPT_SECRET', 'swpt_test_secret_key');
}
if (!defined('ABSPATH')) exit;

/**
 * Chuẩn hoá domain (bỏ http/https/www)
 */
function swpt_normalize_domain($url_or_domain) {
    $host = parse_url($url_or_domain, PHP_URL_HOST);
    if (!$host) $host = $url_or_domain;
    $host = preg_replace('/^www\./i', '', $host);
    return strtolower(trim($host));
}

/**
 * Sinh key theo domain
 */
function swpt_make_key_for_domain($domain) {
    $raw = sha1(swpt_normalize_domain($domain) . SWPT_SECRET);
    $k = strtoupper(substr($raw, 0, 16));
    return substr($k,0,4).'-'.substr($k,4,4).'-'.substr($k,8,4).'-'.substr($k,12,4);
}

/**
 * Validate key nhập từ admin
 */
function swpt_validate_key($key, $url_or_domain = '') {
    $domain = swpt_normalize_domain($url_or_domain ?: home_url());

    // Key mong đợi cho domain hiện tại
    $expected = swpt_make_key_for_domain($domain);

    // Master key (dùng chung cho tất cả site) -> tuỳ chỉnh
    $master_key = 'SWPT-ALL-1607-2023';

    $key = strtoupper(trim($key));

    if ($key === $expected || $key === $master_key) {
        return true;
    }
    return false;
}

/**
 * Check Pro active
 */
function swpt_is_pro_active() {
    $opts = get_option('swpt_options', []);
    $key  = isset($opts['license_key']) ? $opts['license_key'] : '';
    return swpt_validate_key($key, home_url());
}
