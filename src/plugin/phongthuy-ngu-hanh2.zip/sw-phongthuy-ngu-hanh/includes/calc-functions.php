<?php
if (!defined('ABSPATH')) exit;

/**
 * Tính Can, Chi, CanChi, Mệnh theo năm dương lịch. Mốc 1984 = Giáp Tý.
 * Return: array($can, $chi, $can_chi, $menh)
 */
function swpt_calc_can_chi_menh($year) {
	// Mảng Thiên Can: đánh số từ 0 → 9
    // Thiên Can
    $thien_can = [
        "Canh", "Tân","Nhâm", "Quý",
        "Giáp", "Ất", "Bính", "Đinh","Mậu", "Kỷ"
    ];

    // Địa Chi
    $dia_chi  = [
        "Thân", "Dậu", "Tuất", "Hợi", "Tý", "Sửu",
        "Dần", "Mão", "Thìn", "Tỵ", "Ngọ", "Mùi"
    ];

    // Ngũ hành Mệnh
    $menh_map = [
        1 => 'Kim',
        2 => 'Thủy',
        3 => 'Hỏa',
        4 => 'Thổ',
        5 => 'Mộc'
    ];
	
	 // Bước 1: Tính Can
    $can_index = $year % 10;
    $can = $thien_can[$can_index];

    // Bước 2: Tính Chi
    $chi_index = $year % 12;
    $chi = $dia_chi[$chi_index];

    // Ghép Can Chi
    $can_chi = $can . ' ' . $chi;
	// Quy ước điểm Can/Chi để ra mệnh (giống bản bạn đang dùng)
    $can_values = [
        "Giáp"=>1, "Ất"=>1,
        "Bính"=>2, "Đinh"=>2,
        "Mậu"=>3, "Kỷ"=>3,
        "Canh"=>4, "Tân"=>4,
        "Nhâm"=>5, "Quý"=>5
    ];
	$chi_values = [
        "Tý"=>0, "Sửu"=>0, "Ngọ"=>0, "Mùi"=>0,
        "Dần"=>1, "Mão"=>1, "Thân"=>1, "Dậu"=>1,
        "Thìn"=>2, "Tỵ"=>2, "Tuất"=>2, "Hợi"=>2
    ];
	//return $can_chi;
	$menh_index = $can_values[$can] + $chi_values[$chi];
    if ($menh_index > 5) $menh_index -= 5;
    $menh = $menh_map[$menh_index];

   return [
        'can'     => $can,
        'chi'     => $chi,
        'can_chi' => $can_chi,
        'menh'    => $menh
    ];
}

// Bảng palette cho từng mệnh
function swpt_palettes() {
    return [
        "Kim" => [
            "tuong_hop" => [
                'mauhop' => 'Trắng,xám ghi,Vàng',
                'maucss' => ["#FFF701", "#FFFA9E", "#E1DCD9", "#FBFAFC"],
            ],
            "tuong_sinh" => [
                'sinh_vuong' => 'Thổ',
                'mau_ts'     => 'Nâu đất,Vàng',
                'maucss'     => ['#70614E','#68443C','#957F67','#CFBD92'],
            ],
            "khac_che" => [
                'khac'   => 'Hỏa',
                'mau_kc' => 'Đỏ, Hồng,Tím',
                'maucss' => ['#AC2A2A','#DB261D','#E57619','#DFAB8B'],
            ],
        ],

        "Mộc" => [
            "tuong_hop" => [
                'mauhop' => 'xanh lá cây',
                'maucss' => ["#356649", "#3C746B", "#00913F", "#7FC325"],
            ],
            "tuong_sinh" => [
                'sinh_vuong' => 'Thủy',
                'mau_ts'     => 'Đen, Xanh Dương',
                'maucss'     => ['#000000','#2A166F','#0091DF','#94C5E6'],
            ],
            "khac_che" => [
                'khac'   => 'Kim',
                'mau_kc' => 'Vàng, Nâu đất',
                'maucss' => ['#FFF701','#FFFA9E','#E1DCD9','#FBFAFC'],
            ],
        ],

        "Thủy" => [
            "tuong_hop" => [
                'mauhop' => 'Xanh dương, Xanh nước biển,Đen',
                'maucss' => ["#000000", "#2A166F", "#0091DF", "#94C5E6"],
            ],
            "tuong_sinh" => [
                'sinh_vuong' => 'Kim',
                'mau_ts'     => 'Trắng, Xám, Ghi',
                'maucss'     => ['#FBFAFC','#E1DCD9','#FFFA9E','#FFF701'],
            ],
            "khac_che" => [
                'khac'   => 'Thổ',
                'mau_kc' => 'Nâu đất',
                'maucss' => ['#70614E','#68443C','#957F67','#BDA05F'],
            ],
        ],

        "Hỏa" => [
            "tuong_hop" => [
                'mauhop' => 'Đỏ, Cam, Hồng và Tím',
                'maucss' => ["#AC2A2A", "#DB261D", "#DE107C", "#E57619"],
            ],
            "tuong_sinh" => [
                'sinh_vuong' => 'Mộc',
                'mau_ts'     => 'Xanh lá cây',
                'maucss'     => ['#3C746B','#00913F','#7FC325','#b3ed50'],
            ],
            "khac_che" => [
                'khac'   => 'Thủy',
                'mau_kc' => 'Đen, Xanh dương',
                'maucss' => ['#000000','#2A166F','#0091DF','#94C5E6'],
            ],
        ],

        "Thổ" => [
            "tuong_hop" => [
                'mauhop' => 'Vàng đất, Nâu đất',
                'maucss' => ["#70614E", "#68443C", "#BDA05F", "#CFBD92"],
            ],
            "tuong_sinh" => [
                'sinh_vuong' => 'Hỏa',
                'mau_ts'     => 'Đỏ, Hồng, Tím',
                'maucss'     => ['#AC2A2A','#DB261D','#DE107C','#DFAB8B'],
            ],
            "khac_che" => [
                'khac'   => 'Mộc',
                'mau_kc' => 'Xanh lá cây',
                'maucss' => ['#356649','#00913F','#7FC325','#b3ed50'],
            ],
        ],
    ];
}

?>