<?php
if (!defined('ABSPATH')) exit;

/**
 * Render shortcode form phong thủy (chỉ ở single product)
 */
function swpt_render_phongthuy_on_product(){
    if (!function_exists('is_product') || !is_product()) return;
    echo do_shortcode('[swphongthuy]');
}

/**
 * Gắn vào vị trí tương ứng theo option
 */
add_action('wp', function () {
    // Cần WooCommerce
    if (!class_exists('WooCommerce')) return;

    // Cần Pro + đã bật checkbox
    if (!function_exists('swpt_is_pro_active') || !swpt_is_pro_active()) return;

    $opts = get_option('swpt_options', []);
    if (empty($opts['show_on_product'])) return;

    $pos = isset($opts['product_position']) ? $opts['product_position'] : 'after_summary';

    /**
     * Mapping:
     * - after_summary: chèn NGAY SAU mô tả ngắn (excerpt) trong khối summary
     *   (excerpt ở hook woocommerce_single_product_summary priority 20 → chèn 21)
     * - after_image: chèn NGAY SAU ảnh đại diện (gallery) trước phần summary
     *   (ảnh ở hook woocommerce_before_single_product_summary priority 20 → chèn 21)
     */
    if ($pos === 'after_summary') {
        add_action('woocommerce_single_product_summary', 'swpt_render_phongthuy_on_product', 21);
        return;
    }

    if ($pos === 'after_image') {
        add_action('woocommerce_before_single_product_summary', 'swpt_render_phongthuy_on_product', 21);
        return;
    }
});
