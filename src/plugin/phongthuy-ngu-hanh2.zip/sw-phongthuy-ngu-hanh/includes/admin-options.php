<?php
if (!defined('ABSPATH')) exit;

/**
 * Enqueue admin CSS cho trang option của plugin
 */
add_action('admin_enqueue_scripts', function($hook){
    if ($hook === 'settings_page_swpt-options') {
        wp_enqueue_style(
            'swpt-admin-style',
            plugin_dir_url(__FILE__) . '../assets/admin.css',
            [],
            '1.0.0'
        );
    }
});

/**
 * Trang Settings → Phong thủy SW
 */
add_action('admin_menu', function(){
    add_options_page(
        'Phong thủy SW',
        'Phong thủy SW',
        'manage_options',
        'swpt-options',
        'swpt_options_page_render'
    );
});

/**
 * Khai báo setting + field
 */
add_action('admin_init', function(){
    register_setting('swpt_options', 'swpt_options', 'swpt_options_sanitize');

    add_settings_section('swpt_main', 'Thiết lập hiển thị', function(){
        echo '<p>Nhập nội dung mặc định và chữ “Sản phẩm” tuỳ chỉnh để hiển thị trong kết quả.</p>';
    }, 'swpt-options');
	
	// Tiêu đề form hiển thị ngoài
	add_settings_field(
		'form_title',
		'Tiêu đề Form',
		'swpt_field_text',
		'swpt-options',
		'swpt_main',
		['id' => 'form_title']
	);

    // Nội dung mặc định
    add_settings_field(
        'default_text',
        'Nội dung mặc định trước kết quả',
        'swpt_field_textarea',
        'swpt-options',
        'swpt_main',
        ['id' => 'default_text']
    );

    // Nội dung mặc định sau kết quả
    add_settings_field(
        'default_result_text',
        'Nội dung mặc định sau kết quả',
        'swpt_field_textarea',
        'swpt-options',
        'swpt_main',
        ['id' => 'default_result_text']
    );

    // Product text (Pro mới đổi)
    add_settings_field(
        'product_text',
        'Tên “Sản phẩm”',
        'swpt_field_text',
        'swpt-options',
        'swpt_main',
        ['id' => 'product_text']
    );

    // Hiển thị ở trang sản phẩm (Pro mới dùng)
    add_settings_field(
        'show_on_product',
        'Hiển thị form ở trang sản phẩm',
        'swpt_field_checkbox_product',
        'swpt-options',
        'swpt_main',
        ['id' => 'show_on_product']
    );

    add_settings_field(
        'product_position',
        'Vị trí hiển thị',
        'swpt_field_select_position',
        'swpt-options',
        'swpt_main',
        ['id' => 'product_position']
    );

    // License key có nút kiểm tra + auto lưu
    add_settings_field(
        'license_key',
        'License Key',
        'swpt_field_text_license_check',
        'swpt-options',
        'swpt_main',
        ['id' => 'license_key']
    );

    // Hướng dẫn sử dụng
    add_settings_field(
        'swpt_shortcode_info',
        'Hướng dẫn sử dụng',
        'swpt_field_shortcode_info',
        'swpt-options',
        'swpt_main'
    );
});

/**
 * Sanitize option trước khi lưu
 */
function swpt_options_sanitize($input){
    $out = [];

    $out['default_text']        = isset($input['default_text']) ? wp_kses_post($input['default_text']) : '';
    $out['default_result_text'] = isset($input['default_result_text']) ? wp_kses_post($input['default_result_text']) : '';
    $out['form_title'] = isset($input['form_title']) ? sanitize_text_field($input['form_title']) : '';
	
    // Nếu Pro thì cho đổi, Free thì giữ nguyên
    if (swpt_is_pro_active()) {
        $out['product_text'] = isset($input['product_text']) ? sanitize_text_field($input['product_text']) : '';
        $out['show_on_product'] = !empty($input['show_on_product']) ? 1 : 0;
        $out['product_position'] = isset($input['product_position']) ? sanitize_text_field($input['product_position']) : 'after_summary';
    } else {
        $old = get_option('swpt_options', []);
        $out['product_text']     = isset($old['product_text']) ? $old['product_text'] : 'Sản phẩm';
        $out['show_on_product']  = isset($old['show_on_product']) ? $old['show_on_product'] : 0;
        $out['product_position'] = isset($old['product_position']) ? $old['product_position'] : 'after_summary';
    }

    $out['license_key'] = isset($input['license_key']) ? sanitize_text_field($input['license_key']) : '';

    return $out;
}

/**
 * Field textarea với giá trị mặc định
 */
function swpt_field_textarea($args){
    $opts = get_option('swpt_options', []);
    $id   = esc_attr($args['id']);

    $defaults = [
        'default_text' => 'Theo khoa học phong thủy, màu sắc có vai trò to lớn trong việc hỗ trợ và cân bằng, điều tiết hài hòa yếu tố âm dương – ngũ hành của từng người. Do đó việc lựa chọn màu sắc cho trang phục quần áo, giày dép, túi xách, trang sức, màu xe, màu sơn nhà, màu chủ đạo của bàn làm việc vô cùng quan trọng.',
        'default_result_text' => 'Mỗi mệnh khác nhau sẽ hợp với từng tông màu chủ đạo, kèm theo đó là màu sắc sinh vượng và màu khắc chế với màu chủ đạo đó.',
    ];

    $val = isset($opts[$id]) && $opts[$id] !== '' ? $opts[$id] : ($defaults[$id] ?? '');
    $val = esc_textarea($val);

    echo "<textarea id='{$id}' name='swpt_options[{$id}]' rows='5' cols='50' class='large-text'>{$val}</textarea>";

    if ($id === 'default_text') {
        echo "<p class='description'>Nội dung này sẽ hiển thị mặc định ở cột kết quả khi chưa chọn năm sinh.</p>";
    } elseif ($id === 'default_result_text') {
        echo "<p class='description'>Nội dung này sẽ hiển thị thêm sau khi người dùng submit kết quả.</p>";
    }
}

/**
 * Field text input
 */
function swpt_field_text($args){
    $opts = get_option('swpt_options', []);
    $id   = esc_attr($args['id']);
    $val  = isset($opts[$id]) ? esc_attr($opts[$id]) : '';

    $disabled = '';
    if ($id === 'product_text' && !swpt_is_pro_active()) {
        $disabled = 'disabled';
        echo "<input type='text' style='width:75%;' id='{$id}' name='swpt_options[{$id}]' value='{$val}' class='regular-text' {$disabled} />";
        echo "<p class='description'>Chỉ bản Pro mới thay đổi được tên “Sản phẩm”.</p>";
        return;
    }

    echo "<input type='text' id='{$id}' style='width:75%;' name='swpt_options[{$id}]' value='{$val}' class='regular-text' {$disabled} />";
}

/**
 * Checkbox hiển thị form ở trang sản phẩm
 */
function swpt_field_checkbox_product($args){
    $opts = get_option('swpt_options', []);
    $id   = esc_attr($args['id']);
    $val  = !empty($opts[$id]) ? 1 : 0;

    $disabled = '';
    if (!swpt_is_pro_active()) {
        $disabled = 'disabled';
        echo "<input type='checkbox' id='{$id}' name='swpt_options[{$id}]' value='1' ".checked(1,$val,false)." {$disabled} />";
        echo "<p class='description'>Chỉ bản Pro mới có thể bật hiển thị form ở trang sản phẩm.</p>";
        return;
    }

    echo "<input type='checkbox' id='{$id}' name='swpt_options[{$id}]' value='1' ".checked(1,$val,false)." {$disabled} />";
}

/**
 * Select vị trí hiển thị
 */
function swpt_field_select_position($args){
    $opts = get_option('swpt_options', []);
    $id   = esc_attr($args['id']);
    $val  = isset($opts[$id]) ? $opts[$id] : 'after_summary';

    $positions = [
        'after_summary' => 'Dưới mô tả ngắn sản phẩm',
        'after_image'   => 'Dưới ảnh đại diện sản phẩm'
    ];

    $disabled = !swpt_is_pro_active() ? 'disabled' : '';

    echo "<select id='{$id}' name='swpt_options[{$id}]' {$disabled}>";
    foreach ($positions as $k => $label) {
        echo "<option value='{$k}' ".selected($val,$k,false).">{$label}</option>";
    }
    echo "</select>";

    if (!swpt_is_pro_active()) {
        echo "<p class='description'>Chỉ bản Pro mới thay đổi được vị trí hiển thị.</p>";
    }
}

/**
 * Field license key có nút Kiểm tra + auto lưu
 */
function swpt_field_text_license_check($args){
    $opts = get_option('swpt_options', []);
    $id   = esc_attr($args['id']);
    $val  = isset($opts[$id]) ? esc_attr($opts[$id]) : '';

    echo "<input type='text' id='{$id}' name='swpt_options[{$id}]' value='{$val}' class='regular-text' placeholder='XXXX-XXXX-XXXX-XXXX' />";
    echo " <button type='button' class='button' id='swpt-check-key'>Kiểm tra</button>";
    echo " <span id='swpt-key-status' style='margin-left:8px'></span>";

    if (function_exists('swpt_is_pro_active')) {
        $ok  = swpt_is_pro_active();
        $msg = $ok ? 'SWPT Pro: License hợp lệ.' : 'SWPT Pro: Chưa kích hoạt hoặc license không hợp lệ.';
        $cls = $ok ? 'color:#0a0' : 'color:#aa0';
        echo "<p style='{$cls};margin-top:6px' id='swpt-key-saved-status'>{$msg}</p>";
    }

    $nonce = wp_create_nonce('swpt_check_license_nonce');
    echo "<input type='hidden' id='swpt_check_nonce' value='{$nonce}' />";

    ?>
    <script>
    (function($){
      $(document).on('click', '#swpt-check-key', function(){
        var k = $('#<?php echo $id; ?>').val();
        $('#swpt-key-status').css('color','#333').text('Đang kiểm tra...');
        $.post(ajaxurl, {
          action: 'swpt_check_license',
          key: k,
          _ajax_nonce: $('#swpt_check_nonce').val()
        }, function(res){
          if(res && res.success){
            $('#swpt-key-status').css('color','#0a0').text('Hợp lệ (đã lưu)');
            $('#swpt-key-saved-status').css('color','#0a0').text('SWPT Pro: License hợp lệ.');
          } else {
            $('#swpt-key-status').css('color','#a60').text('Không hợp lệ');
            $('#swpt-key-saved-status').css('color','#aa0').text('SWPT Pro: Chưa kích hoạt hoặc license không hợp lệ.');
          }
        }, 'json').fail(function(){
          $('#swpt-key-status').css('color','#a00').text('Lỗi mạng');
        });
      });
    })(jQuery);
    </script>
    <?php
}

/**
 * Hướng dẫn sử dụng shortcode
 */
function swpt_field_shortcode_info(){
    echo '<p>Bạn có thể chèn form xem màu phong thủy vào bất kỳ bài viết hoặc trang nào bằng cách sử dụng shortcode sau:</p>';
    echo '<code>[swphongthuy]</code>';
    echo '<p class="description">Ví dụ: tạo một Trang mới, dán shortcode trên vào nội dung để hiển thị form.</p>';
}

/**
 * Render trang Options
 */
function swpt_options_page_render(){
    ?>
    <div class="wrap">
        <h1>Phong thủy SW - Cài đặt</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('swpt_options');
            do_settings_sections('swpt-options');
            submit_button();
            ?>
        </form>
    </div>
    <?php
}

/**
 * AJAX handler kiểm tra key + auto lưu
 */
add_action('wp_ajax_swpt_check_license', function(){
    check_ajax_referer('swpt_check_license_nonce');
    if (!current_user_can('manage_options')) wp_send_json_error('no-permission');

    $key = isset($_POST['key']) ? sanitize_text_field($_POST['key']) : '';
    if (!$key) wp_send_json_error('empty-key');

    $ok = function_exists('swpt_validate_key') ? swpt_validate_key($key, home_url()) : false;

    if ($ok) {
        $opts = get_option('swpt_options', []);
        $opts['license_key'] = $key;
        update_option('swpt_options', $opts);
        wp_send_json_success();
    } else {
        wp_send_json_error();
    }
});
