<?php
if (!defined('ABSPATH')) exit;

/** Shortcode: [swphongthuy] */
add_shortcode('swphongthuy', 'swpt_shortcode_render'); 
function swpt_shortcode_render($atts=[]){
  $opts = get_option('swpt_options', []);
  $form_title = !empty($opts['form_title']) ? esc_html($opts['form_title']) : 'TRA CỨU PHỐI MÀU NỘI THẤT HỢP MỆNH.';
  ob_start();
  ?>
	<div class="sw_mau_phongthuy">
		<div class="mau_phongthuy_left swboxpt">
			<div class="mau_phongthuy_inner">
				<p><strong><?php echo $form_title; ?></strong></p>
			    <form method="post" id="mau_phongthuy" action="">
                    <div class="phongthuy_col">
                        <label for="nam_sinh">Năm sinh gia chủ:</label>
                        <select id="nam_sinh" name="nam_sinh" required>
                            <option value="">Chọn năm sinh</option>
                            <?php
                            $currentY = abs((int)date('Y'));
                            for ($year = 1930; $year <= $currentY; $year++) {
                                echo "<option value='{$year}'>{$year}</option>";
                            } ?>
                        </select>
                    </div>
                    <div class="phongthuy_col_full">
                        <button type="submit" class="btn">Xem kết quả</button>
                    </div>
                    <div id="tua-loading" class="loading-spinner" style="display:none">…</div>
                    <?php wp_nonce_field('swpt_nonce'); ?>
                </form>
			</div><!--end inner--> 
		</div><!--end left-->
		
		<div class="mau_phongthuy_right swboxpt">
			<div class="mau_phongthuy_inner">
				<strong class="phongthuy_title">Kết quả</strong>
				<div id="tua-age-result"></div>
				<div id="mau_phongthuy_result" class="mau_phongthuy_result">
                    <p>Theo khoa học phong thủy, màu sắc có vai trò to lớn trong việc hỗ trợ và cân bằng, điều tiết hài hòa yếu tố âm dương – ngũ hành của từng người.</p>
                </div>
			</div><!--end inner-->
		</div><!--end right-->
	</div><!--end swphongthuy-->
  <?php
  return ob_get_clean();
}

?>