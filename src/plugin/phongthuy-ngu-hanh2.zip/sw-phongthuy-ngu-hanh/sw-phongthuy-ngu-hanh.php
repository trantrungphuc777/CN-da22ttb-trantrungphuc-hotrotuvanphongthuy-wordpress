<?php 
/**
 * Plugin Name: An Trạch_Màu Sắc Nội Thất
 * Description: Xem màu sắc nội thất tương hợp với tuổi
 * Version: 1.0
 * Author: Trần Trung Phúc
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define('SWPT_PATH', plugin_dir_path(__FILE__));
define('SWPT_URL',  plugin_dir_url(__FILE__));

require_once SWPT_PATH.'includes/calc-functions.php';
require_once SWPT_PATH.'includes/ajax-functions.php';
require_once SWPT_PATH.'includes/shortcode-functions.php';
require_once SWPT_PATH.'includes/admin-options.php';
require_once SWPT_PATH.'includes/license-functions.php';
require_once plugin_dir_path(__FILE__) . 'includes/woo-hooks.php';


/** Frontend assets */
add_action('wp_enqueue_scripts', function(){
    wp_enqueue_style('swpt-style', SWPT_URL.'assets/css/style.css', [], '1.1.0');
    wp_enqueue_script('swpt-main', SWPT_URL.'assets/js/main.js', ['jquery'], '1.1.0', true);
    wp_localize_script('swpt-main','swptAjax',[
        'ajaxurl' => admin_url('admin-ajax.php'),
        'nonce'   => wp_create_nonce('swpt_nonce'),
    ]);
});

/** Khởi tạo shortcode & ajax (functional nên chỉ cần add_action/add_shortcode trong file tương ứng) */


// 1. Link "Settings" ngay trên màn Plugins
add_filter('plugin_action_links_' . plugin_basename(__FILE__), function($links){
    $url = admin_url('options-general.php?page=swpt-options');
    $links[] = '<a href="'.esc_url($url).'">'.esc_html__('Settings', 'sonweb').'</a>';
    return $links;
});

// 2. Redirect về trang Options ngay sau khi kích hoạt plugin
register_activation_hook(__FILE__, function(){
    add_option('swpt_do_activation_redirect', 1);
});
add_action('admin_init', function(){
    if (get_option('swpt_do_activation_redirect')) {
        delete_option('swpt_do_activation_redirect');
        if (!isset($_GET['activate-multi'])) {
            wp_safe_redirect(admin_url('options-general.php?page=swpt-options'));
            exit;
        }
    }
});

 ?>