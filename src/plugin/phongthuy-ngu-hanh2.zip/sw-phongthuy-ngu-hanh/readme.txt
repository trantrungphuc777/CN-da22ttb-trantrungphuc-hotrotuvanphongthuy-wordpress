=== Phong Thủy SW ===
Author: SonWeb
Contributors: SonWeb
Tags: phong thuy, xem mau hop menh, can chi, ngũ hành, wooCommerce
Donate link: https://paypal.me/sonwebtl/2usd
Requires at least: 5.0
Tested up to: 6.5
Stable tag: 1.0.0
Requires PHP: 7.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl.html

Plugin xem màu sắc phong thủy theo năm sinh (Can Chi, Ngũ Hành) và gợi ý màu hợp – tương sinh – khắc chế. Có thể chèn vào bất kỳ Trang hoặc Bài viết bằng shortcode.

== Description ==

**Phong Thủy SW** cho phép người dùng:  
- Nhập năm sinh → tính Can Chi (Thiên Can – Địa Chi)  
- Tự động xác định Mệnh (Ngũ Hành)  
- Hiển thị màu sắc hợp mệnh, màu tương sinh, màu khắc chế kèm bảng màu trực quan  
- Có shortcode `[swphongthuy]` để chèn vào bất kỳ Trang / Bài viết  
- Bản Pro: tích hợp hiển thị ngay trong trang sản phẩm WooCommerce

== Features ==

* Tính Thiên Can, Địa Chi theo năm sinh  
* Xác định Mệnh (Ngũ Hành)  
* Hiển thị màu bản mệnh, màu sinh vượng, màu khắc chế  
* Form hiển thị đẹp, responsive  
* Shortcode `[swphongthuy]` dễ dùng  
* Bản Pro: hiển thị form trực tiếp trong trang sản phẩm WooCommerce, tùy chọn vị trí

== Installation ==

1. Upload folder `phongthuy-sw` vào thư mục `/wp-content/plugins/`  
2. Kích hoạt plugin trong menu **Plugins** của WordPress  
3. Vào **Settings → Phong thủy SW** để cấu hình  
4. Chèn shortcode `[swphongthuy]` vào bài viết hoặc trang để hiển thị form

== Frequently Asked Questions ==

= Làm sao để hiển thị trong trang sản phẩm WooCommerce? =  
Chức năng này chỉ có trong bản Pro. Vào **Settings → Phong thủy SW**, tick vào ô “Hiển thị form ở trang sản phẩm”, chọn vị trí hiển thị.

= Có thể đổi chữ "Sản phẩm" thành chữ khác không? =  
Có, nhưng chỉ bản Pro mới cho phép chỉnh text này.

= Làm sao kiểm tra license key? =  
Nhập key được cấp → nhấn nút **Kiểm tra** trong Settings. Nếu hợp lệ, plugin sẽ bật đầy đủ tính năng Pro.

== Screenshots ==

1. Form chọn năm sinh và hiển thị kết quả màu sắc phong thủy  
2. Màn hình cài đặt trong Admin với các tùy chọn cơ bản  
3. Phiên bản Pro cho phép bật hiển thị trong trang sản phẩm WooCommerce

== Changelog ==

= 1.0.0 =
* First release: Form chọn năm sinh, tính Can Chi + Ngũ Hành, gợi ý màu sắc hợp mệnh.
