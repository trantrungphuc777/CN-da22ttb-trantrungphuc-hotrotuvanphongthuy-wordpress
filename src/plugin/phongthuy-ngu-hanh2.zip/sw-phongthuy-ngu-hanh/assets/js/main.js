jQuery(function($) {
	$('#mau_phongthuy').on('submit',function(e) {
		e.preventDefault();
		const y = parseInt($('#nam_sinh').val(),10);
		if ( !y || y < 1000 || y > 3000) {
			alert('Vui lòng chọn năm sinh hợp lệ');
			return;
		}
		$('#tua-loading').show();
		$.post(swptAjax.ajaxurl, {
			action: 'sw_calculate_age',
			birth_year: y,
			_ajax_nonce: swptAjax.nonce
		},function(res) {
			// callback khi request thành công
			$('#tua-loading').hide();
			if(res && res.success){
				$('#mau_phongthuy_result').hide();
				$('#tua-age-result').html(res.data.message);
			}else {
				$('#tua-age-result').html('<p> Có lỗi xảy ra.</p>');
			}
		},'json').fail(function() {
			// callback khi requet thất bại
			$('#tua-loading').hide();
			alert('Lỗi mạng');
		});// fail 
	}); // end sumbit form 
});