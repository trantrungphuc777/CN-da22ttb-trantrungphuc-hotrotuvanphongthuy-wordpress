<?php
/**
 * Plugin Name: An Trạch_Lọc Sản Phẩm
 * Description: Lọc sản phẩm với các bộ lọc khác nhau
 * Author: Trần Trung Phúc
 **/

/**
 * Base config constants and functions.
 */
require_once dirname(__FILE__) . DIRECTORY_SEPARATOR . 'config.php';
require_once dirname(__FILE__) . DIRECTORY_SEPARATOR . 'functions.php';

/**
 * HPOS.
 */
add_action( 'before_woocommerce_init', function () {
	if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
	}
} );

/**
 * Connect all required core classes.
 */
if ( trueRequestWpf() ) {

	importClassWpf( 'DbWpf' );
	importClassWpf( 'InstallerWpf' );
	importClassWpf( 'BaseObjectWpf' );
	importClassWpf( 'ModuleWpf' );
	importClassWpf( 'ModelWpf' );
	importClassWpf( 'ViewWpf' );
	importClassWpf( 'ControllerWpf' );
	importClassWpf( 'HelperWpf' );
	importClassWpf( 'DispatcherWpf' );
	importClassWpf( 'FieldWpf' );
	importClassWpf( 'TableWpf' );
	importClassWpf( 'FrameWpf' );

	/**
	 * Deprecated classes.
	 *
	 * @deprecated since version 1.0.1
	 */
	importClassWpf( 'LangWpf' );
	importClassWpf( 'ReqWpf' );
	importClassWpf( 'UriWpf' );
	importClassWpf( 'HtmlWpf' );
	importClassWpf( 'ResponseWpf' );
	importClassWpf( 'FieldAdapterWpf' );
	importClassWpf( 'ValidatorWpf' );
	importClassWpf( 'ErrorsWpf' );
	importClassWpf( 'UtilsWpf' );
	importClassWpf( 'ModInstallerWpf' );
	importClassWpf( 'InstallerDbUpdaterWpf' );
	importClassWpf( 'DateWpf' );

	/**
	 * Check plugin version - maybe we need to update database, and check global errors in request.
	 */
	InstallerWpf::update();
	ErrorsWpf::init();

	/**
	 * Start application.
	 */
	FrameWpf::_()->parseRoute();
	FrameWpf::_()->init();
	FrameWpf::_()->exec();

}
