<?php
if ($isPro) {
	DispatcherWpf::doAction('addEditTabFilters', 'partEditTabFiltersSearchText');
} else {
	?>
	<div class="row-settings-block col-md-12">
		<?php if (FrameWpf::_()->isWCLicense()) { ?>
		<img class="wpfProAd" src="<?php echo esc_url($adPath . 'search_text.png'); ?>">
		<?php } else { ?>
		<a href="<?php echo ''; ?>" target="_blank">
			<img class="wpfProAd" src="<?php echo esc_url($adPath . 'search_text.png'); ?>">
		</a>
		<?php } ?>
	</div>
<?php } ?>
