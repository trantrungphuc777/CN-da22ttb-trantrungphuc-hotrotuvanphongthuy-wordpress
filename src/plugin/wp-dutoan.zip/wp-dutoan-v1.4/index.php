<?php
/*
Plugin Name: WP Dự Toán Xây Dựng
Description: Dự toán xây dựng nhà ở.
Version: 1.0
Author: Trần Trung Phúc
*/
define( 'WPDT_URI', plugin_dir_url( __FILE__ ) );
define( 'WPDT_VERSION', '1.0' );
define( 'WPDT_LOAINHA', 'Nhà phố 1 mặt tiền, Nhà phố 2 mặt tiền, Biệt thự hiện đại, Biệt thự cổ điển phong cách Châu Âu, Biệt thự lâu đài cao cấp' );
define( 'WPDT_DICHVU', 'Xây thô, Xây thô + hoàn thiện trung bình, Xây thô + hoàn thiện trung bình khá, Xây thô + hoàn thiện tốt, Xây thô + hoàn thiện cao cấp' );
add_action( 'init', 'wpdt_init' );
add_action( 'admin_menu', 'wpdt_settings_page' );
add_action( 'wp_enqueue_scripts', 'wpdt_enqueue_scripts' );
add_action( 'wp_ajax_wpdt_ajax_tracuu', 'wpdt_process_ajax_tracuu' );
add_action( 'wp_ajax_nopriv_wpdt_ajax_tracuu', 'wpdt_process_ajax_tracuu' );
function wpdt_enqueue_scripts() {
	// main
	wp_enqueue_style( 'wpdt', WPDT_URI . 'assets/css/frontend.css' );
	wp_enqueue_script( 'wpdt', WPDT_URI . 'assets/js/frontend.js', array( 'jquery' ), WPDT_VERSION, true );
	wp_localize_script( 'wpdt', 'wpdt_vars', array(
		'ajax_url'   => admin_url( 'admin-ajax.php' ),
		'wpdt_nonce' => wp_create_nonce( 'wpdt-nonce' )
	) );
}

function wpdt_process_ajax_tracuu() {
	if ( ! isset( $_POST['wpdt_nonce'] ) || ! wp_verify_nonce( $_POST['wpdt_nonce'], 'wpdt-nonce' ) ) {
		die( 'Permissions check failed!' );
	}
	$loainha_arr = explode( ',', get_option( '_wpdt_loai_nha', WPDT_LOAINHA ) );
	$dichvu_arr  = explode( ',', get_option( '_wpdt_dich_vu', WPDT_DICHVU ) );
	$loainha     = isset( $_POST['loainha'] ) ? (string) $_POST['loainha'] : '0';
	$dichvu      = isset( $_POST['dichvu'] ) ? (string) $_POST['dichvu'] : '0';
	$dientich    = isset( $_POST['dientich'] ) ? $_POST['dientich'] : '';
	$sotang      = isset( $_POST['sotang'] ) ? $_POST['sotang'] : '';
	$gia_key     = '_wpdt_gia_' . $loainha . '_' . $dichvu;
	$gia         = get_option( $gia_key, '10-12' );
	$gia         = wpdt_format_gia( $gia );
	if ( strpos( $gia, '-' ) !== false ) {
		$gia_arr = explode( '-', $gia );
		$gia_min = $gia_arr[0];
		$gia_max = $gia_arr[1];
	} else {
		$gia_min = $gia_max = $gia;
	}
	if ( ( $dientich != '' ) && ( $sotang != '' ) ) {
		$tong_min = $gia_min * $dientich * $sotang;
		$tong_max = $gia_max * $dientich * $sotang;
		if ( $tong_min >= 1000 ) {
			$tong_min_text = round( $tong_min / 1000, 2 ) . ' tỷ';
		} else {
			$tong_min_text = $tong_min . ' triệu';
		}
		if ( $tong_max >= 1000 ) {
			$tong_max_text = round( $tong_max / 1000, 2 ) . ' tỷ';
		} else {
			$tong_max_text = $tong_max . ' triệu';
		}
		$output = '<hr/><div class="box">Chào quý khách, theo yêu cầu của quý khách:<br/>
 + Loại nhà: ' . $loainha_arr[ $loainha ] . '<br/>
 + Dịch vụ: ' . $dichvu_arr[ $dichvu ] . '<br/>
 + Diện tích: ' . $dientich . ' m2<br/>
 + Số tầng: ' . $sotang . ' tầng</div><hr/>';
		if ( ( $tong_min > 0 ) && ( $tong_max > 0 ) ) {
			$output .= '<div class="box">Chúng tôi xin gửi đơn giá tham khảo ước tính khoảng từ: <strong>' . $tong_min_text . '</strong> trở lên <strong>' . '</strong></div>';
		} else {
			$output .= 'Chúng tôi không cung cấp gói ' . $dichvu_arr[ $dichvu ] . ' cho ' . $loainha_arr[ $loainha ] . '. Quý khách vui lòng lựa chọn gói hoàn thiện cao cấp hơn.';
		}
	} else {
		$output = '<hr/>Xin vui lòng điền đầy đủ thông tin!';
	}
	$output .= '<hr/><div class="box">Quý khách vui lòng liên hệ theo hotline <strong>0365 530 100</strong> để được tư vấn chi tiết và dự toán chính xác nhất. Trân trọng cám ơn.</div>';
	echo $output;
	die();
}

function wpdt_format_gia( $gia ) {
	$gia = str_replace( ' ', '', $gia );
	$gia = str_replace( ',', '.', $gia );

	return $gia;
}

function wpdt_init() {
	// shortcode
	add_shortcode( 'wp_dutoan', 'wpdt_shortcode_dutoan' );
}

function wpdt_shortcode_dutoan( $atts ) {
	ob_start();
	$uid = uniqid( 'wp_dutoan_' );
	?>
	<div
		class="wp_dutoan <?php echo( isset( $atts['style'] ) && ( $atts['style'] == '2' ) ? 'style_02' : 'style_01' ); ?>"
		id="<?php echo esc_attr( $uid ); ?>">
		<div class="content">
			<?php
			if ( isset( $atts['style'] ) && ( $atts['style'] == '2' ) ) {
				echo '<div class="title"><span>Dự toán công trình</span></div>';
			}
			?>
			<div class="desc">Dự toán tham khảo báo giá xây dựng nhà trọn gói, khách hàng có thể tra cứu
				ngay tại đây:
			</div>
			<div class="form">
				<?php
				$loainha = explode( ',', get_option( '_wpdt_loai_nha', WPDT_LOAINHA ) );
				$dichvu  = explode( ',', get_option( '_wpdt_dich_vu', WPDT_DICHVU ) );
				?>
				<table>
					<tr>
						<td>
							<select class="val select_val wpdt_loainha">
								<?php
								if ( is_array( $loainha ) && ( count( $loainha ) > 0 ) ) {
									foreach ( $loainha as $ln_key => $ln ) {
										echo '<option value="' . $ln_key . '">' . $ln . '</option>';
									}
								}
								?>
							</select>
						</td>
						<td>
							<select class="val select_val wpdt_dichvu">
								<?php
								if ( is_array( $dichvu ) && ( count( $dichvu ) > 0 ) ) {
									foreach ( $dichvu as $dv_key => $dv ) {
										echo '<option value="' . $dv_key . '">' . $dv . '</option>';
									}
								}
								?>
							</select>
						</td>
					</tr>
					<tr>
						<td>
							<input class="val wpdt_dientich" type="number" min="1" max="10000"
							       placeholder="Diện tích (m2)"/>
						</td>
						<td><input class="val wpdt_sotang" type="number" min="1" max="1000" placeholder="Số tầng"/></td>
					</tr>
				</table>
				<input class="wpdt_tracuu" type="submit" value="Tra cứu"/>
			</div>
			<div class="kq"></div>
		</div>
	</div>
	<?php
	$wpdt_output = ob_get_contents();
	ob_end_clean();

	return $wpdt_output;
}

function wpdt_settings_page() {
	add_menu_page(
		'Dự toán',
		'Dự toán',
		'manage_options',
		'wpdt',
		'wpdt_settings_page_content',
		'dashicons-portfolio',
		6
	);
}

function wpdt_settings_page_content() {
	?>
	<div class="wrap" id="wpdt-settings-page">
		<h1>Dự Toán</h1>
		<form method="post" action="options.php">
			<?php wp_nonce_field( 'update-options' ) ?>
			<h2 class="title">1. Thiết lập lựa chọn</h2>
			<p>Sau khi thiết lập danh sách các lựa chọn xong hãy nhấn
				<strong>Update Options</strong> sau đó tiếp tục thiết lập giá cho các lựa chọn.</p>
			<table class="form-table">
				<tr>
					<th scope="row">Loại nhà</th>
					<td>
						<input type="text" value="<?php echo get_option( '_wpdt_loai_nha', WPDT_LOAINHA ); ?>"
						       name="_wpdt_loai_nha" class="large-text"/>
						<p class="description">Danh sách các loại nhà, cách nhau bởi dấu phẩy</p>
					</td>
				</tr>
				<tr>
					<th scope="row">Dịch vụ</th>
					<td>
						<input type="text" value="<?php echo get_option( '_wpdt_dich_vu', WPDT_DICHVU ); ?>"
						       name="_wpdt_dich_vu" class="large-text"/>
						<p class="description">Danh sách các dịch vụ, cách nhau bởi dấu phẩy</p>
					</td>
				</tr>
			</table>
			<h2 class="title">2. Thiết lập giá</h2>
			<p>Thiết lập giá cho từng lựa chọn, chỉ gồm số, dấu phẩy và dấu gạch ngang. Ví dụ
				<code>10,5-20,5</code> hoặc <code>30-50</code>, đơn vị là triệu/m2</p>
			<?php
			$options_arr = array( '_wpdt_loai_nha', '_wpdt_dich_vu' );
			$loainha     = explode( ',', get_option( '_wpdt_loai_nha', WPDT_LOAINHA ) );
			$dichvu      = explode( ',', get_option( '_wpdt_dich_vu', WPDT_DICHVU ) );
			if ( is_array( $loainha ) && ( count( $loainha ) > 0 ) && is_array( $dichvu ) && ( count( $dichvu ) > 0 ) ) {
				?>
				<table class="form-table" style=" border: 1px solid #ddd; ">
					<thead>
					<td>&nbsp;</td>
					<?php
					foreach ( $dichvu as $dv_key => $dv ) {
						echo '<td style=" border: 1px solid #ddd; ">' . trim( $dv ) . '</td>';
					}
					?>
					</thead>
					<?php
					foreach ( $loainha as $ln_key => $ln ) {
						?>
						<tr>
							<td scope="row" style=" border: 1px solid #ddd; "><?php echo trim( $ln ); ?></td>
							<?php
							foreach ( $dichvu as $dv_key => $dv ) {
								$option_key    = '_wpdt_gia_' . $ln_key . '_' . $dv_key;
								$options_arr[] = $option_key;
								?>
								<td style=" border: 1px solid #ddd; ">
									<input type="text" value="<?php echo get_option( $option_key, '10-12' ); ?>"
									       name="<?php echo esc_attr( $option_key ); ?>"/>
								</td>
								<?php
							} ?>
						</tr>
						<?php
					}
					?>
				</table>
				<?php
			}
			?>
			<table class="form-table">
				<tr>
					<th scope="row">
						<input type="submit" name="Submit" class="button button-primary"
						       value="Update Options"/>
						<input type="hidden" name="action" value="update"/>
						<?php
						$options = implode( ',', $options_arr );
						?>
						<input type="hidden" name="page_options"
						       value="<?php echo esc_attr( $options ); ?>"/>
					</th>
					<td>&nbsp;</td>
				</tr>
			</table>
		</form>
	</div>
	<?php
}