jQuery(document).ready(function () {

	jQuery('.wp_huongbantho .xem').on('click', function () {

		var this_form = jQuery(this).closest('.wp_huongbantho');

		var namsinh = this_form.find('select.ns').val();

		var gioitinh = this_form.find('select.gt').val();

		var huongnha = this_form.find('select.hn').val();

		this_form.addClass('loading');

		wpbt_ajax_get_huongbantho(namsinh, gioitinh, huongnha);

	});

});



function wpbt_ajax_get_huongbantho(namsinh, gioitinh, huongnha) {
	var data = {
		action     : 'wpbt_ajax_huongbantho',
		namsinh    : namsinh,
		gioitinh   : gioitinh,
		huongnha   : huongnha,
		wpbt_nonce : wpbt_vars.wpbt_nonce
	};

	jQuery.ajax({
		url: wpbt_vars.ajax_url,
		type: 'POST',
		data: data,
		success: function(response) {
			jQuery('.wp_huongbantho').removeClass('loading');
			
			// Trim response to remove any whitespace
			var cleanResponse = jQuery.trim(response);
			
			if (cleanResponse && cleanResponse.length > 0) {
				jQuery.featherlight({html: cleanResponse});
			} else {
				alert('Không nhận được dữ liệu từ server!');
			}
		},
		error: function(xhr, status, error) {
			jQuery('.wp_huongbantho').removeClass('loading');
			console.error('AJAX Error:', status, error);
			console.log('Response:', xhr.responseText);
			alert('Lỗi kết nối! Vui lòng thử lại.');
		}
	});
}