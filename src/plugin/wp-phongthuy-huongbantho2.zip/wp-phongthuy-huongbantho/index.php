<?php

/*

Plugin Name: An Trạch_Bàn Thờ tại gia

Description: Xem hướng đặt bàn thờ tại gia.

Author: Trần Trung Phúc


*/

define( 'WPBT_URI', plugin_dir_url( __FILE__ ) );

define( 'WPBT_PATH', plugin_dir_path( __FILE__ ) );

define( 'WPBT_VERSION', '1.0' );

add_action( 'init', 'wpbt_init' );

add_action( 'wp_enqueue_scripts', 'wpbt_enqueue_scripts' );

add_action( 'wp_ajax_wpbt_ajax_huongbantho', 'wpbt_process_ajax_huongbantho' );

add_action( 'wp_ajax_nopriv_wpbt_ajax_huongbantho', 'wpbt_process_ajax_huongbantho' );

function wpbt_enqueue_scripts() {

	// featherlight

	wp_enqueue_style( 'featherlight', WPBT_URI . 'libs/featherlight/featherlight.css' );

	wp_enqueue_script( 'featherlight', WPBT_URI . 'libs/featherlight/featherlight.js', array( 'jquery' ), WPBT_VERSION, true );

	// main

	wp_enqueue_style( 'wpbt', WPBT_URI . 'assets/css/frontend.css' );

	wp_enqueue_script( 'wpbt', WPBT_URI . 'assets/js/frontend.js', array( 'jquery' ), WPBT_VERSION, true );

	wp_localize_script( 'wpbt', 'wpbt_vars', array(

		'ajax_url'   => admin_url( 'admin-ajax.php' ),

		'wpbt_nonce' => wp_create_nonce( 'wpbt-nonce' )

	) );

}



function wpbt_init() {

	// huong ban tho

	register_post_type( 'wpbt-huong-ban-tho', array(

			'labels'             => array(

				'name' => esc_html__( 'Hướng bàn thờ', 'wpbt' )

			),

			'public'             => false,

			'menu_position'      => 8,

			'has_archive'        => false,

			'publicly_queryable' => true,

			'show_ui'            => true,

			'hierarchical'       => false,

			'query_var'          => true,

		)

	);

	register_taxonomy(

		'wpbt-nam-sinh', 'wpbt-huong-ban-tho', array(

			'label'        => esc_html__( 'Năm sinh', 'wpbt' ),

			'hierarchical' => true,

			'query_var'    => true

		)

	);

	register_taxonomy(

		'wpbt-gioi-tinh', 'wpbt-huong-ban-tho', array(

			'label'        => esc_html__( 'Giới tính', 'wpbt' ),

			'hierarchical' => true,

			'query_var'    => true

		)

	);

	register_taxonomy(

		'wpbt-huong-nha', 'wpbt-huong-ban-tho', array(

			'label'        => esc_html__( 'Hướng nhà', 'wpbt' ),

			'hierarchical' => true,

			'query_var'    => true

		)

	);

	// shortcode

	add_shortcode( 'wp_huongbantho', 'wpbt_shortcode_huongbantho' );

}



function wpbt_shortcode_huongbantho() {

	$namsinh  = get_terms( array(

		'taxonomy'   => 'wpbt-nam-sinh',

		'orderby'    => 'term_id',

		'hide_empty' => false,

	) );

	$goitinh  = get_terms( array(

		'taxonomy'   => 'wpbt-gioi-tinh',

		'orderby'    => 'term_id',

		'hide_empty' => false,

	) );

	$huongnha = get_terms( array(

		'taxonomy'   => 'wpbt-huong-nha',

		'orderby'    => 'term_id',

		'hide_empty' => false,

	) );

	$output   = '<div class="wp_phongthuy_form wp_huongbantho wp-huongbantho wp-hbt">';

	$output .= '<div class="form-title"><span>GỢI Ý HƯỚNG ĐẶT BÀN THỜ TẠI GIA</span></div>';

	$output .= '<div class="form-line"><span class="label">Nam sinh gia chủ</span><div class="select"><table><tr><td><select class="ns">';

	if ( ! empty( $namsinh ) && ! is_wp_error( $namsinh ) ) {

		foreach ( $namsinh as $ns ) {

			$output .= '<option value="' . esc_attr( $ns->slug ) . '">' . esc_html( $ns->name ) . '</option>';

		}

	}

	$output .= '</select></td><td><select class="gt">';

	if ( ! empty( $goitinh ) && ! is_wp_error( $goitinh ) ) {

		foreach ( $goitinh as $gt ) {

			$output .= '<option value="' . esc_attr( $gt->slug ) . '">' . esc_html( $gt->name ) . '</option>';

		}

	}

	$output .= '</select></td></tr></table></div></div>';

	$output .= '<div class="form-line"><span class="label">Hướng nhà</span><div class="select"><select class="hn">';

	if ( ! empty( $huongnha ) && ! is_wp_error( $huongnha ) ) {

		foreach ( $huongnha as $hn ) {

			$output .= '<option value="' . esc_attr( $hn->slug ) . '">' . esc_html( $hn->name ) . '</option>';

		}

	}

	$output .= '</select></div></div>';

	$output .= '<div class="form-line"><input type="button" class="xem" value="Xem ngay"></div>';

	$output .= '</div>';



	return $output;

}



function wpbt_process_ajax_huongbantho() {	// Set proper headers
	@header('Content-Type: text/html; charset=utf-8');
		// Verify nonce
	if ( ! isset( $_POST['wpbt_nonce'] ) || ! wp_verify_nonce( $_POST['wpbt_nonce'], 'wpbt-nonce' ) ) {
		echo '<div class="wp_phongthuy_popup">Lỗi bảo mật! Vui lòng tải lại trang.</div>';
		wp_die();
	}

	$namsinh  = isset( $_POST['namsinh'] ) ? sanitize_text_field( $_POST['namsinh'] ) : '1900';
	$gioitinh = isset( $_POST['gioitinh'] ) ? sanitize_text_field( $_POST['gioitinh'] ) : 'nam';
	$huongnha = isset( $_POST['huongnha'] ) ? sanitize_text_field( $_POST['huongnha'] ) : 'huong-dong';

	$args = array(
		'post_type'      => 'wpbt-huong-ban-tho',
		'posts_per_page' => 1,
		'tax_query'      => array(
			'relation' => 'AND',
			array(
				'taxonomy' => 'wpbt-nam-sinh',
				'terms'    => $namsinh,
				'field'    => 'slug',
			),
			array(
				'taxonomy' => 'wpbt-gioi-tinh',
				'terms'    => $gioitinh,
				'field'    => 'slug',
			),
			array(
				'taxonomy' => 'wpbt-huong-nha',
				'terms'    => $huongnha,
				'field'    => 'slug',
			)
		),
	);

	$query = new WP_Query( $args );
	$output = '';

	if ( $query->have_posts() ) {
		while ( $query->have_posts() ) {
			$query->the_post();
			$content = get_the_content();
			$content = str_replace( '{batquai}', '<img src="' . WPBT_URI . 'assets/images/batquai.jpg"/>', $content );
			$output .= '<div class="wp_phongthuy_popup">' . $content . '</div>';
		}
		wp_reset_postdata();
	} elseif ( file_exists( WPBT_PATH . '/data/huongnha/' . $namsinh . '_' . $gioitinh . '_' . $huongnha . '.txt' ) ) {
		$txt_content = file_get_contents( WPBT_PATH . '/data/huongnha/' . $namsinh . '_' . $gioitinh . '_' . $huongnha . '.txt' );
		$output .= '<div class="wp_phongthuy_popup">' . $txt_content . '</div>';
	} else {
		$output .= '<div class="wp_phongthuy_popup">Không tìm thấy dữ liệu, xin vui lòng thử lại!</div>';
	}

	echo $output;
	wp_die();
}