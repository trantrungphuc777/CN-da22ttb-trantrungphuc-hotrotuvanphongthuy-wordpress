=====================================================
PLUGIN WORDPRESS: AN TRẠCH_BÀN THỜ TẠI GIA v1.3
=====================================================

I. THÔNG TIN CHUNG
------------------
- Tên Plugin: An Trạch_Bàn thờ tại gia
- Phiên bản: 1.3
- Chức năng: Tra cứu hướng đặt bàn thờ theo phong thủy
- Shortcode: [wp_huongbantho]

II. CẤU TRÚC THỦ MỤC
-------------------
wp-phongthuy-v1.3/
├── index.php                           # File chính của plugin
├── assets/                            # Tài nguyên frontend
│   ├── css/frontend.css
│   ├── js/frontend.js
│   └── images/
├── data_xemhuong_tuoixaydung/        # Dữ liệu phong thủy
│   └── xemhuongnha/
│       └── thitknithtsnh.wordpress.2018-11-19.xml  # 1920 tổ hợp dữ liệu
└── libs/                              # Thư viện bên thứ 3
    └── featherlight/

III. DỮ LIỆU ĐÃ CẬP NHẬT (8 HƯỚNG)
----------------------------------
✅ HƯỚNG CÁT (Auspicious):
1. Sinh khí: Tài lộc phúc đức, phát triển lâu dài
2. Thiên y: Che chở phù trợ, sức khỏe tốt
3. Diên niên: Ổn định hòa thuận, vợ chồng hòa hợp
4. Phục vị: Bình an trợ lực, được phù hộ

❌ HƯỚNG HUNG (Inauspicious):
5. Họa hại: Thị phi tai tiếng, bất ổn
6. Lục sát: Sát khí mâu thuẫn, tranh cãi
7. Ngũ quỉ: Đại hung tai họa, biến cố
8. Tuyệt mệnh: Xấu nhất, ảnh hưởng nghiêm trọng

IV. CÁCH SỬ DỤNG
---------------
1. Upload plugin vào thư mục wp-content/plugins/
2. Vào WordPress Admin > Plugins > Activate
3. Thêm shortcode [wp_huongbantho] vào trang/bài viết
4. Người dùng chọn: Năm sinh + Giới tính + Hướng nhà
5. Hệ thống trả về: Hướng đặt bàn thờ phù hợp

V. KỸ THUẬT
-----------
- Dữ liệu: XML với 1920 tổ hợp (năm sinh × giới tính × hướng nhà)
- Số lượng thay thế: 8 hướng × 1920 = 15,360 replacements
- Encoding: UTF-8 (Vietnamese characters)
- AJAX handler: wpbt_process_ajax_huongbantho()

VI. NGUỒN THAM KHẢO
------------------
Sách "Xây Dựng Nhà Ở Theo Địa Lý - Thiên Văn - Dịch Lý"
Tác giả: Trần Văn Tam
NXB Văn hóa thông tin năm 2002

=====================================================
Cập nhật dữ liệu: 2024
Verified: All 8 direction descriptions successfully replaced
=====================================================
